java -jar -Xmx4G splitter.jar 4sq.yaml
