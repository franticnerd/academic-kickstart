This tool is developed for extracting local event from geo-tagged tweet data.  It is an implementation of the following paper:

"GeoBurst: Real-Time Local Event Detection in Geo-Tagged Tweet Streams". Chao Zhang, Guangyu Zhou, Quan Yuan, Honglei Zhuang, Yu Zheng, Lance Kaplan, Shaowen Wang, Jiawei Han. Proceedings of the 39th Annual International ACM SIGIR Conference (SIGIR), 2016.

==================== Input ====================

* tweets.txt
  - This file contains the geo-tagged tweets sorted chronologically;
  - Each line corresponds to one geo-tagged tweet with the following fields (separated by tabs): tweet_id, user_id, timestamp, latitude, longitude, keyword_ids;
  - The timestamp field represents the offset from the first tweet in seconds (the timestamp of the first tweet is 0).
  - As each tweet can contain multiple keywords, the keyword_ids are separated by tabs.

* queries.txt
  - This file contains the query time windows;
  - All the time query windows MUST be non-overlapping and sorted chronologically;
  - Each line corresponds to one query window with the fields: start timestamp, end timestamp. Again, the start timestamp and end timestamp are separated by a tab.

* words.txt
  - This file contains the mapping from keyword_ids to keywords. Each line specifies the mapping: keyword_id -> keyword.

==================== Output ====================

* events.txt
  - This file contains all the result local events;
  - Each line corresponds to the results for one query in the queries.txt file;
  - Each line is in JSON format that specifies the members, scores, etc.;

* word_similarities.txt
  - This file contains the similarity information for the keywords;
  - Each line corresponds to one keyword, and specifies the neighbors of that keyword in JSON;


==================== Parameters ====================

All the parameters can be specified in a YAML file. We provide a sample YAML file: ny40k.yaml.

The parameters are described as follows:

* dir: the directory for the input and output
* clustream: this set of parameters specify the runtime options for CluStream
  - calcVicinity: a boolean parameter for deciding whether computing keyword from scratch or reading them from the word_similarities.txt file
  - pRestart: the RWR restart probability
  - errorBound: the error threshold for calculating keyword similarities on the co-occurrence graph
  - numInitClusters: the initial number of micro-clusters (TCs)
  - numMaxClusters: the maximum number of micro-clusters (TCs)
  - numInitTweets: the number of tweets for building the initial clusters in the burn-in period
  - numTweetPeriod: the number of tweets that we periodically remove outdated TCs
  - outdatedThreshold: the threshold for removing outdated TCs

* candidate: this set of parameters are for controlling the pivot seeking clustering algorithm
  - bandwidth: the spatial kernel bandwidth
  - epsilon: the RWR similarity threshold

* rank: this set of parameters control the candidate ranking procedure
  - refWindowSize: the length of the reference window (in seconds)
  - eta: the parameter for balancing the spatial and temporal burstiness
  - minSup: the minimum number of tweets for a geo-topical cluster to be considered as a valid candidate
  - K: the number of local events in each query window


Example command for running this tool:
java -jar -Xmx2G geoburst.jar ny40k.yaml
